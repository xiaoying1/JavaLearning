package com.hisen.bean.response;

/**
 * Created by hisen on 17-8-26.
 * E-mail: hisenyuan@gmail.com
 */
public class CommonResponse {

  private int resCode;
  private String resMsg;

  public int getResCode() {
    return resCode;
  }

  public void setResCode(int resCode) {
    this.resCode = resCode;
  }

  public String getResMsg() {
    return resMsg;
  }

  public void setResMsg(String resMsg) {
    this.resMsg = resMsg;
  }
}
