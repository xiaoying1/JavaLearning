package com.hisen.bean.request;

import java.util.Date;

/**
 * Created by hisen on 17-8-26.
 * E-mail: hisenyuan@gmail.com
 */
public class CommonRequest {
  private Date time = new Date();

  public Date getTime() {
    return time;
  }
}
