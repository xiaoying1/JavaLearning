package com.itranswarp.learnjava.bean;

public class SignInBean {

	public String email;
	public String password;

}
