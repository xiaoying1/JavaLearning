package com.itranswarp.sample;

public class Greeting {

	public String hello(String name) {
		return "Hello, " + name + "!";
	}
}
